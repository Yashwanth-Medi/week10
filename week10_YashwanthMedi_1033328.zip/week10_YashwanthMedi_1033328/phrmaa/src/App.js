import logo from './logo.svg';
import './App.css';
import Pharmacy from './Pharmacy';

function App() {
  return (
   <Pharmacy/>
  );
}

export default App;
