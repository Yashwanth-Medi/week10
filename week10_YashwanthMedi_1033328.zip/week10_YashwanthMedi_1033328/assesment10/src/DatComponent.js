import DataServiceComponent from "./DataServiceComponent";
import { useEffect, useState } from "react";

function DatComponent() {

    const [posts, setPosts] = useState([])

    useEffect(() => {
        getData()
    }, [])

    const getData = () => {
        DataServiceComponent.getData().then((result) => {
            console.log(result.data.data);
            setPosts(result.data.data);
        });
    };

    return (
        <div>
            <h1><center>Data Table</center></h1><hr />
            <table align="center" cellSpacing={30}>
                <thead>
                    <th>ID Nation</th>
                    <th>Year</th>
                    <th>Population</th>
                </thead>
                <tbody>
                    {
                        posts.map(
                            data =>
                                <tr key={data.Nation}>
                                    <td>{data["ID Nation"]}</td>
                                    <td>{data.Year}</td>
                                    <td>{data.Population}</td>
                                </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    );
}

export default DatComponent;