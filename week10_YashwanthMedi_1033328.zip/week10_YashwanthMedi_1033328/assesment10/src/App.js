import './App.css';
import axios from 'axios';
import DatComponent from './DatComponent';
 
function App() {
  
 
  return (
    <DatComponent/>
  );
}
 
export default App;