import React from "react";
import axios from "axios";

const DATABASE = "https://datausa.io/api/data?drilldowns=Nation&measures=Population"
 
class DataServiceComponent{
    getData(){
        return axios.get(DATABASE);
    }
   
}
 
export default new DataServiceComponent;